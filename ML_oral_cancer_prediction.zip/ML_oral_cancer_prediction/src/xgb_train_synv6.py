import yaml
import os
import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.preprocessing import OneHotEncoder, LabelEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
#from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    classification_report, confusion_matrix, roc_curve
)

# Load YAML config
CONFIG_PATH = "/content/drive/MyDrive/oral_cancer_prediction/configs/syn_xgb_config_v6.yaml"
with open(CONFIG_PATH, "r") as f:
    config = yaml.safe_load(f)

# Extract config parts
data_cfg = config["data"]
model_cfg = config["model"]
output_cfg = config["output"]
project_cfg = config["project"]
tuning_cfg = config.get("tuning", {"enabled": False})


# Load dataset
df = pd.read_csv(data_cfg["path"])

# Read feature groups from YAML
cat_cols = data_cfg["features"]["categorical"]
num_cols = data_cfg["features"]["numeric"]

# Safety check: catch typos or missing engineered columns early
missing = [c for c in (cat_cols + num_cols) if c not in df.columns]
if missing:
    raise ValueError(f"The following columns from YAML are missing in the dataset: {missing}")

# Build X and y
X = df[cat_cols + num_cols].copy()
y = df[data_cfg["target"]].copy()

# Encode target labels
le = LabelEncoder()
y_encoded = le.fit_transform(y)


# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y_encoded,
    test_size=project_cfg["test_size"],
    random_state=project_cfg["random_state"],
    stratify=y_encoded,
)

# Preprocessing
preprocess = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat_cols),
        ("num", "passthrough", num_cols),
    ],
    remainder="drop"
)

#  Model setup
xgb_params = model_cfg["parameters"]
xgb = XGBClassifier(**xgb_params)

pipeline = Pipeline(steps=[
    ("preprocess", preprocess),
    ("model", xgb)
])

if tuning_cfg["enabled"]:
    print(" Running RandomizedSearchCV for hyperparameter tuning...")
    search = RandomizedSearchCV(
        estimator=pipeline,
        param_distributions={
            f"model__{k}": v for k, v in tuning_cfg["param_distributions"].items()
        },
        n_iter=tuning_cfg["n_iter"],
        cv=tuning_cfg["cv_folds"],
        scoring=tuning_cfg["scoring"],
        n_jobs=-1,
        random_state=tuning_cfg["random_state"],
        verbose=2,
        refit=True
    )
    search.fit(X_train, y_train)
    pipeline = search.best_estimator_
    print("\n Best Parameters Found:")
    for k, v in search.best_params_.items():
        print(f"{k}: {v}")
    # ===== CV RESULTS =====
    cv_df = pd.DataFrame(search.cv_results_)
    print("\n CROSS-VALIDATION PERFORMANCE (Top 10)")
    print(
        cv_df[['mean_test_score', 'std_test_score']]
        .sort_values('mean_test_score', ascending=False)
        .head(10)
    )
else:
    pipeline.fit(X_train, y_train)

#  Train
#pipeline.fit(X_train, y_train)

#Evaluate TRAINING SET to detect overfitting 
y_train_pred = pipeline.predict(X_train)
y_train_proba = pipeline.predict_proba(X_train)[:, 1]

train_acc  = accuracy_score(y_train, y_train_pred)
train_auc  = roc_auc_score(y_train, y_train_proba)

print("\n TRAINING PERFORMANCE (for overfitting check)")
print(f"Training Accuracy: {train_acc:.4f}")
print(f"Training AUC:      {train_auc:.4f}")

# Evaluate
y_pred = pipeline.predict(X_test)
y_proba = pipeline.predict_proba(X_test)[:, 1]

acc  = accuracy_score(y_test, y_pred)
prec = precision_score(y_test, y_pred, zero_division=0)
rec  = recall_score(y_test, y_pred)
f1   = f1_score(y_test, y_pred)
auc  = roc_auc_score(y_test, y_proba)

report = classification_report(y_test, y_pred, target_names=le.classes_)
cm = confusion_matrix(y_test, y_pred)

print("==== RESULTS ====")
print(f"Accuracy : {acc:.4f}")
print(f"Precision: {prec:.4f}")
print(f"Recall   : {rec:.4f}")
print(f"F1-score : {f1:.4f}")
print(f"ROC-AUC  : {auc:.4f}")
print("\nClassification Report:\n", report)
print("Confusion Matrix:\n", cm)

fpr, tpr, thresholds = roc_curve(y_test, y_proba)
best_thr = thresholds[(tpr - fpr).argmax()]  # Youden's J statistic

print(f"\n Best Threshold Found: {best_thr:.4f}")

# Apply new threshold
y_pred_opt = (y_proba >= best_thr).astype(int)

# Compute optimized metrics
opt_acc  = accuracy_score(y_test, y_pred_opt)
opt_prec = precision_score(y_test, y_pred_opt, zero_division=0)
opt_rec  = recall_score(y_test, y_pred_opt)
opt_f1   = f1_score(y_test, y_pred_opt)
opt_auc  = roc_auc_score(y_test, y_proba)

print("\n===== OPTIMIZED THRESHOLD RESULTS =====")
print(f"Optimized Accuracy : {opt_acc:.4f}")
print(f"Optimized Precision: {opt_prec:.4f}")
print(f"Optimized Recall   : {opt_rec:.4f}")
print(f"Optimized F1-score : {opt_f1:.4f}")
print(f"ROC-AUC            : {opt_auc:.4f}")
print("\n=======================================\n")

# Save model & metrics
os.makedirs(os.path.dirname(output_cfg["model_path"]), exist_ok=True)
os.makedirs(os.path.dirname(output_cfg["metrics_path"]), exist_ok=True)

joblib.dump(pipeline, output_cfg["model_path"])

with open(output_cfg["metrics_path"], "w") as f:
    f.write(
        f"Accuracy:  {acc:.6f}\n"
        f"Precision: {prec:.6f}\n"
        f"Recall:    {rec:.6f}\n"
        f"F1:        {f1:.6f}\n"
        f"ROC-AUC:   {auc:.6f}\n\n"
        f"Confusion Matrix:\n{cm}\n\n"
        f"{report}\n"
    )

print(f"\n Model saved to: {output_cfg['model_path']}")
print(f" Metrics saved to: {output_cfg['metrics_path']}")
